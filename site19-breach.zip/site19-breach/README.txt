SITE-19 BREACH
Open index.html in a desktop browser (Chrome, Edge, Firefox). No install needed.
Fonts load from Google Fonts when online and fall back to system fonts offline.
Controls: WASD move, Shift run, Mouse look, Space blink, Esc pause.
