SITE-19 BREACH
Open index.html in a desktop browser (Chrome, Edge, Firefox). Needs internet for the 3D library.
Controls: WASD move, Shift run, Mouse look, Space blink, Esc pause.
Admin console: press F2 or ` (backtick). Default password: breach-4471 (change it inside the panel).
